Sistema de ventas desarrollado en Laravel

Posee los módulos Artículos, Categorías, Clientes, Proveedores,
Cuenta corriente, Ventas, Ingresos, Devoluciones, Se podrán agregar
nuevas características a convenir. El sistema incluye también,
-Factura electrónica con conexión a web service de AFIP –
-Impresión de comprobante en impresora térmica.
-Lectura de productos por código de barras
-Modificación masiva de precios por categoría
-API para sincronización con Woocommerce 

