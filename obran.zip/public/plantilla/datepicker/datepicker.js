    $('.datepicker').datepicker({
    	  setDate: new Date(),
        format: "yyyy-mm-dd",
        language: "es",
        autoclose: false
    });
