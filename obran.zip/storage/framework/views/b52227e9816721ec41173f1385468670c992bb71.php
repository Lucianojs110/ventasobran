<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(URL::to('/')); ?>/admin/css/jquery.dataTables.min.css">
    <style>
        table.dataTable tfoot th, table.dataTable tfoot td {
            padding: 0px 0px 0px 0px;
            border-top: 1px solid #111;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="box">
            <div class="box-header with-border">
                <div class="row">
                    <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
                        <h3>Detalle del Arqueo: <?php echo e(date("d-m-Y", strtotime($arqueo->fecha_hora))); ?>  <a  href="#" data-toggle="modal" data-target="#agregar" class="btn btn-success btn-xs"><i class="fa fa-edit"></i> Agrega Arqueo</a></h3>
                        <hr>
                    </div>
                </div>
                <?php echo $__env->make('arqueo.modal-agregar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="table-responsive">
                            <table id="show" class="table table-striped table-bordered table-condensed table-hover">
                                <thead>
                                <th>Hora</th>
                                <th>Descripción</th>
                                <th>Tipo Venta</th>
                                <th>Cantidad</th>
                                <th>Monto</th>
                                <th>Total</th>
                                </thead>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(URL::to('/')); ?>/admin/js/jquery.dataTables.min.js"></script>
    <script>

        $('#show').DataTable({
            processing: true,
            serverSide: true,
            ajax: "<?php echo e(route('arqueo.show.tabla', $id)); ?>",
            columns: [
                {data: 'hora', name: 'hora'},
                {data: 'descripcion', name: 'descripcion'},
                {data: 'tipo_venta', name: 'tipo_venta'},
                {data: 'cantidad', name: 'cantidad'},
                {data: 'monto', name: 'monto'},
                {data: 'total', name: 'total'}
                // {data: 'opcion', name: 'opcion', orderable: false, searchable: false}
            ],
            "language": {
                "url": "<?php echo e(URL::to('/')); ?>/admin/Spanish.json"
            }
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sisventaobran\resources\views/arqueo/show.blade.php ENDPATH**/ ?>