<html>
<head>
    <meta charset="utf-8">
    <style>
        body {
            font-family: Arial, Helvetica, sans-serif;
        }

        table {
            font-family: "Lucida Sans Unicode", "Lucida Grande", Sans-Serif;
            font-size: 12px;
            margin: 45px;
            width: 100%;
            text-align: left;
            border-collapse: collapse;
            margin-right: auto;
            margin-left: auto;
        }

        th {
            font-size: 13px;
            font-weight: bold;
            padding: 8px;
            color: #000000;
        }

        td {
            padding: 8px;
            border-top: 1px solid transparent;
        }

    </style>
</head>
<body>
<h2 style="text-align: center">Mis Proveedores</h2>
<table border="1px">
    <tr>
        <th>Nombre</th>
        <th>Documento</th>
        <th>Teléfono</th>
        <th>Email</th>
    </tr>
    <?php $__currentLoopData = $personas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $per): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($per->nombre); ?></td>
            <td><?php echo e($per->tipo_documento); ?> - <?php echo e($per->num_documento); ?></td>
            <td><?php echo e($per->telefono); ?></td>
            <td><?php echo e($per->email); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</body>
</html><?php /**PATH D:\xampp\htdocs\sisventanew\resources\views/pdf/proveedor.blade.php ENDPATH**/ ?>