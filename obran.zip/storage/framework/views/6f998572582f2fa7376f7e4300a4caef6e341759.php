<div class="modal modal-warning fade in" id="modal-show-<?php echo e($cli->idpersona); ?>" >
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span></button>
                <h4 class="modal-title"><i data-toggle="tooltip" title="Historial de compra del cliente: <?php echo e($cli->nombre); ?>" class="fa fa-eye"></i> Historial de compra del cliente: <?php echo e($cli->nombre); ?></h4>
            </div>
            <div style="overflow-y: auto; background-color: #ffffff !important;color: black !important;" class="modal-body">
                <div  class="table-responsive table-wrapper">
                    <table style="overflow-y: scroll;" class="table table-bordered table-hover">
                        <thead>
                        <tr>
                            <th>Fecha</th>
                            <th>Numero de comprobante</th>
                            <th>Pago con efectivo</th>
                            <th>Pago con debito</th>
                            <th>Pago con tarjeta</th>
                            <th>Total</th>
                        </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $cli->ventas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ven): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th><?php echo e($ven->fecha_hora); ?></th>
                                    <th><?php echo e($ven->num_comprobante); ?></th>
                                    <th><?php echo e($ven->paga); ?> $</th>
                                    <th><?php echo e($ven->tarjeta_debito); ?> $</th>
                                    <th><?php echo e($ven->tarjeta_credito); ?> $</th>
                                    <th><?php echo e($ven->total_venta); ?> $</th>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                
            </div>
            <div class="modal-footer">
                <button type="reset" class="btn btn-outline pull-left btn-xs" data-dismiss="modal"><i class="fa fa-window-close"></i> Cerrar</button>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div><?php /**PATH D:\xampp\htdocs\sisventanew\resources\views\ventas\cliente\modal-show.blade.php ENDPATH**/ ?>