<div class="modal modal-danger" aria-hidden="true" role="dialog" tabindex="-1" id="modal_cerrar-<?php echo e($arq->idarqueo); ?>">


    <?php echo Form::model($arq,['route'=>['arqueo.update', $arq->idarqueo] , 'id'=>'borrar-'.$arq->idarqueo.'', 'method'=>'put']); ?>

    <?php echo e(Form::token()); ?>



    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden='true'>x</span>
                </button>
                <h4 class="modal-title"><i class="fa fa-trash"></i> Cerrar Arqueo</h4>
            </div>
            <?php if($arq->estado=="Cerrado"): ?>
            <div class="modal-body"style="overflow-y: auto;background-color: #ffffff !important; color: black !important;">
                 <p style="text-align: center">El Arqueo de caja ya ha sido cerrado</p>  
            </div>
            <div class="modal-footer">
                <button type="reset" class="btn btn-outline pull-left btn-xs" data-dismiss="modal"> <i class="fa fa-window-close"></i> Cancelar</button>
               
            </div>
            <?php else: ?> 
            <div class="modal-body"style="overflow-y: auto;background-color: #ffffff !important; color: black !important;">
                <p style="text-align: center">Confirme si desea cerrar el arqueo de caja</p> 
            </div>
            <div class="modal-footer">
                <button type="reset" class="btn btn-outline pull-left btn-xs" data-dismiss="modal"> <i class="fa fa-window-close"></i> Cancelar</button>
                <button type="submit" form="borrar-<?php echo e($arq->idarqueo); ?>" class="btn btn-outline btn-xs"> <i class="fa fa-save"></i> Confirmar</button>
            </div>
            <?php endif; ?>
        </div>
    </div>
    <?php echo e(Form::Close()); ?>


</div><?php /**PATH C:\laragon\www\sisventa\resources\views/arqueo/modal-cerrar.blade.php ENDPATH**/ ?>