<div class="modal modal-warning fade in" id="modal-show-<?php echo e($art->idarticulo); ?>">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span></button>
                <h4 class="modal-title"><i data-toggle="tooltip" title="Historial del artículo: <?php echo e($art->nombre); ?>"
                                           class="fa fa-eye"></i> Historial del artículo: <?php echo e($art->nombre); ?></h4>
            </div>
            <div style="overflow-y: auto; background-color: #ffffff !important;color: black !important;"
                 class="modal-body">
                <?php
                    $ultimov = $art->detalleVentas->first();
                    $ultimoi = $art->detalleIngresos->first();
                ?>
                
                <?php if($art->imagen != ""): ?>
            <img src="<?php echo e(asset('/imagenes/articulos/'.$art->imagen)); ?>" alt="<?php echo e($art->imagen); ?>" height="200px" width="200px">
            <?php endif; ?>
                
                <div class="table-responsive">
                    <table class="table table-bordered table-hover">
                        <thead>
                        <tr>
                            <th>Artículo</th>
                            <th>Codígo</th>
                            <th>Stock</th>
                            <th>Categoría</th>
                            <th>Precio Venta</th>
                            <th>Precio Compra</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr>
                            <th><?php echo e($art->nombre); ?></th>
                            <th><?php echo e($art->codigo); ?></th>
                            <th><?php echo e($art->stock); ?></th>
                            <th><?php echo e($art->categorias->nombre); ?></th>
                            <th><?php echo e($art->precio_venta); ?></th>
                            <?php if($ultimoi != null): ?>
                                <th><?php echo e($ultimoi['precio_compra']); ?> $</th>
                            <?php else: ?>
                                <th>0$</th>
                            <?php endif; ?>

                        </tr>
                        </tbody>
                    </table>
                </div>
                <div class="table-responsive table-wrapper">
                    <table style="overflow-y: scroll;" class="table table-bordered table-hover">
                        <thead>
                        <tr>
                            <th>Fecha</th>
                            <th>Cantidad</th>
                            <th>Tipo</th>
                            <th>Precio Venta</th>
                            <th>Precio Compra</th>
                            <th>Total</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                            $todo = collect([$art->detalleVentas,$art->detalleIngresos,$art->detalleDevoluciones])
                            ->collapse()
                            ->sortByDesc(function($ordenar){
                                return $ordenar->created_at;
                            });

                        ?>
                        <?php $__currentLoopData = $todo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $art): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr style="<?php echo e(isset($art->iddetalle_venta) ? 'background: #71f994;' : ""); ?>

                            <?php echo e(isset($art->iddetalle_ingreso) ? 'background:#71daf9' : ""); ?>

                            <?php echo e(isset($art->iddevolucion) ? 'background: #f1a7a7;' : ""); ?> ">
                                <?php if(isset($art->iddetalle_venta)): ?>
                                    <th><?php echo e(date("d-m-Y", strtotime($art->created_at))); ?></th>
                                    <th class="text-derecha"><?php echo e(number_format($art->cantidad, 2, '.', '')); ?></th>
                                    <th scope="row"><span class="label label-success">Venta</span></th>
                                    <th class="text-derecha"><?php echo e($art->precio_venta); ?> $</th>
                                    <?php if(isset($art->precio_compra)): ?>
                                        <th class="text-derecha"><?php echo e($art->precio_compra); ?> $</th>
                                    <?php else: ?>
                                        <th class="text-derecha"></th>
                                    <?php endif; ?>
                                    <th class="text-derecha"><?php echo e($art->precio_venta*$art->cantidad); ?> $
                                        <small class="label pull-right bg-green">Entrada</small>
                                    </th>
                                <?php endif; ?>
                                <?php if(isset($art->iddetalle_ingreso)): ?>
                                    <th><?php echo e(date("d-m-Y", strtotime($art->created_at))); ?></th>
                                    <th class="text-derecha"><?php echo e(number_format($art->cantidad, 2, '.', '')); ?></th>
                                    <th scope="row"><span class="label label-info">Ingreso</span></th>
                                    <th class="text-derecha"><?php echo e($art->precio_venta); ?> $</th>
                                    <?php if(isset($art->precio_compra)): ?>
                                        <th class="text-derecha"><?php echo e($art->precio_compra); ?> $</th>
                                    <?php else: ?>
                                        <th class="text-derecha"></th>
                                    <?php endif; ?>
                                    <th class="text-derecha"><?php echo e($art->precio_compra*$art->cantidad); ?> $
                                        <small class="label pull-right bg-red">Salida</small>
                                    </th>
                                <?php endif; ?>
                                <?php if(isset($art->iddevolucion)): ?>
                                    <th><?php echo e(date("d-m-Y", strtotime($art->created_at))); ?></th>
                                    <th class="text-derecha"><?php echo e(number_format($art->cantidad, 2, '.', '')); ?></th>
                                    <th scope="row"><span class="label label-warning">Devolución</span></th>
                                    <th class="text-derecha">Mirar en el ultimo ingreso</th>
                                    <th class="text-derecha"><?php echo e($art->sube_resta); ?></th>
                                    <th class="text-derecha">
                                        <small class="label pull-right bg-red">Devolucion</small>
                                    </th>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>


            </div>
            <div class="modal-footer">
                <button type="reset" class="btn btn-outline pull-left btn-xs" data-dismiss="modal"><i
                            class="fa fa-window-close"></i> Cerrar
                </button>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div><?php /**PATH C:\laragon\www\sisventa\resources\views/almacen/articulo/modal-show.blade.php ENDPATH**/ ?>