<div class="modal modal-success" aria-hidden="true" role="dialog" tabindex="-1" id="modal-devo">
    <?php echo Form::open(['route' => 'devolucion.store', 'method'=>'POST','autocomplete' => 'off']); ?>

    <?php echo e(Form::token()); ?>

    <div class="modal-dialog modal-lg">
        <div class="modal-content ">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden='true'>x</span>
                </button>
                <h4 class="modal-title" ><i class="fa fa-undo"></i> Devolución de productos del cliente: <?php echo e($venta->cliente->nombre); ?></h4>
            </div>
            <div class="modal-body" style="background-color: #ffffff !important;color: black !important;">
                <table id="detalles" class="table table-striped table-bordered table-condensed table-hover">
                    <thead>
                    <th>Artículos</th>
                    <th>Cantidad</th>
                    <th>Resta o Suma Stock</th>
                    <th>Descripción</th>
                    </thead>
                    <?php $__currentLoopData = $venta->detalles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $det): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($det->articulo->nombre); ?> <input type="hidden" name="idarticulo[]" value="<?php echo e($det->idarticulo); ?>"></td>
                            <td class="text-derecha"><input min="0" max="<?php echo e($det->cantidad); ?>" class="form-control" type="number" value="<?php echo e($det->cantidad); ?>" name="cantidad[]"></td>
                            <td class="text-derecha">
                                <select name="suma_resta[]" class="form-control">
                                    <option value="sumar">Sumar al Stock</option>
                                    <option value="restar">No sumar al Stock</option>
                                </select>
                            </td>
                            <td><textarea class="form-control" name="descripcion[]" rows="3">

									</textarea></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </table>

                <input name="idventa" value="<?php echo e($venta->idventa); ?>" type="hidden">
                <input name="num_factura" value="<?php echo e($venta->num_comprobante); ?>" type="hidden">
                <input name="idcliente" value="<?php echo e($venta->cliente->idpersona); ?>" type="hidden">
                <input name="num_comprobante" value="<?php echo e(count($devo) + 1); ?>" type="hidden">
            </div>
            <div class="modal-footer">
                <button type="reset" class="btn btn-outline pull-left  btn-xs" data-dismiss="modal"><i class="fa fa-window-close"></i> Cancelar</button>
                <button type="submit" class="btn btn-outline  btn-xs"><i class="fa fa-save"></i> Guardar</button>
            </div>
        </div>
    </div>
    <?php echo e(Form::Close()); ?>


</div><?php /**PATH C:\laragon\www\sisventaobran\resources\views/ventas/venta/modal-devolucion.blade.php ENDPATH**/ ?>