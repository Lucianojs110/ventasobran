<div class="modal fade modal-info" id="modal-editar-<?php echo e($use->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
     aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <h5 class="modal-title" id="exampleModalLabel"><i class="fa fa-edit"></i> Editar usuario: <?php echo e($use->name); ?></h5>
            </div>
            <div style="height: 600px; overflow-y: auto !important;background-color: #ffffff !important;color: black !important;" class="modal-body">
                <?php echo Form::model($use,['route'=>['usuarios.update', $use->id] , 'id'=>'edit-'.$use->id.'', 'method'=>'put', 'enctype'=>'multipart/form-data']); ?>

                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <label for="">Nombre</label>
                        <input  value="<?php echo e($use->name); ?>" type="text" name="name" class="form-control">
                    </div>
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <label for="">Apellido</label>
                        <input required value="<?php echo e($use->apellido); ?>" type="text" name="apellido" class="form-control">
                    </div>
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <label for="">Correo</label>
                        <input value="<?php echo e($use->email); ?>" type="email" name="email" class="form-control">
                    </div>
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <label class="fuente" for="documento">Cambiar contraseña (sino desea cambiarla, no modificar
                            campo)</label>
                        <input type="password" class="form-control" name="password"/>
                    </div>

                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <label class="text-gray-700" for="rol">Rol:</label>
                        <select name="rol" class="form-control">
                            <?php $__currentLoopData = $user_roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usrol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($usrol->user_id == $use->id): ?>

                                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rols): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($usrol->role_id == $rols->id): ?>
                                            <option value="<?php echo e($rols->id); ?>" selected> <?php echo e($rols->name); ?> </option>
                                        <?php else: ?>
                                            <option value="<?php echo e($rols->id); ?>"> <?php echo e($rols->name); ?> </option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>

                    </div>

                    <?php
                     $arraysucursal= array();
                     foreach ($sucursalesUser as $sucursalUser) {
                        if($sucursalUser->user_id == $use->id ){
			               array_push($arraysucursal, $sucursalUser->sucursal_id);
                          }
		                 }
                    ?>

                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <label class="text-gray-700" for="suc">Sucursales:</label>
                        <select class="form-control selectpicker" multiple name="suc[]">
                            <?php $__currentLoopData = $sucursales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sucursal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?=  in_array($sucursal->id,  $arraysucursal) ? 'SELECTED' : '' ?>  value="<?php echo e($sucursal->id); ?>" > <?php echo e($sucursal->nombre); ?> </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    

                </div>
                <?php echo Form::close(); ?>

            </div>
            <div class="modal-footer">
                <button type="reset" class="btn btn-outline pull-left  btn-xs" data-dismiss="modal"><i
                            class="fa fa-window-close"></i> Cancelar
                </button>
                <button type="submit" form="edit-<?php echo e($use->id); ?>" class="btn btn-outline  btn-xs"><i
                            class="fa fa-save"></i> Guardar
                </button>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\laragon\www\sisventaobran\resources\views/usuarios/modal-editar.blade.php ENDPATH**/ ?>