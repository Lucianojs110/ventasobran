<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="box">
            <div class="box-header with-border">
                <div class="row">
                    <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
                        <h3>Listado de Categorías</h3>
                    </div>
                </div>
                <div class="row">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['Supervisor', 'Superadmin'])): ?>
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                        <h3>Nueva categoría</h3>
                        <?php echo Form::open(['route' => 'categoria.store', 'method'=>'post']); ?>

                        <?php echo e(Form::token()); ?>

                        <div class="form-group">
                            <label for="nombre">Nombre</label>
                            <input type="text" id="nombre_ca" name="nombre" class="form-control"
                                   placeholder="Nombre...">
                        </div>
                        <div class="form-group">
                            <label for="descripcion">Descripcion</label>
                            <input type="text" name="descripcion" id="descripcion_ca" class="form-control"
                                   placeholder="Descripcion...">
                        </div>
                        <div class="form-group">
                            <button data-toggle="tooltip" title="Guardar Categoría" class="btn btn-primary btn-xs"
                                    type="submit"><i class="fa fa-save"></i> Guardar
                            </button>
                            <button data-toggle="tooltip" title="Cancelar" class="btn btn-danger btn-xs" type="reset"><i
                                        class="fa fa-window-close"></i> Cancelar
                            </button>
                        </div>
                        <?php echo Form::close(); ?>

                    </div>
                    <?php endif; ?>
                    <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo $__env->make('almacen.categoria.modal-editar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php echo $__env->make('almacen.categoria.modal-borrar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                        <div class="table">
                            <table id="cat" class="table table-striped table-bordered table-condensed table-hover">
                                <thead>
                                <th>Nombre</th>
                                <th>Descripción</th>
                                <th>Opciones</th>
                                </thead>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready(function () {
            $('[data-toggle="tooltip"]').tooltip();
        });
        $('#cat').DataTable({
            processing: true,
            serverSide: true,
            iDisplayLength: 5,
            order: [[0, "desc"]],
            ajax: "<?php echo e(route('categoria.tabla')); ?>",
            columns: [
                {data: 'nombre', name: 'nombre'},
                {data: 'descripcion', name: 'descripcion'},
                {data: 'opcion', name: 'opcion', orderable: false, searchable: false}
            ],
            "language": {
                "url": "<?php echo e(URL::to('/')); ?>/admin/Spanish.json"
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sisventaobran\resources\views/almacen/categoria/indexx.blade.php ENDPATH**/ ?>