<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <?php if(isset($config) == false): ?>
        <title>Ventas</title>
    <?php else: ?>
        <title><?php if($config->nombre !=null): ?> <?php echo e($config->nombre); ?> <?php endif; ?></title>
    <?php endif; ?>
    
    <link rel="icon" type="image/png" href="<?php echo e(asset('imagenes/config/favicon.png')); ?>" />
    
 <!-- ./wrapper -->
                <!-- jQuery 2.2.3 -->
                <script src="<?php echo e(URL::to('/')); ?>/plantilla/js/jquery-2.2.3.min.js"></script>

                <?php echo $__env->yieldPushContent('scripts'); ?>
                <!-- Bootstrap 3.3.6 -->
                <script src="<?php echo e(URL::to('/')); ?>/plantilla/js/bootstrap.min.js"></script>
                <!--select con buscador-->
                <script src="<?php echo e(URL::to('/')); ?>/plantilla/js/bootstrap-select.min.js"></script>
                <!-- FastClick -->
                <script src="<?php echo e(URL::to('/')); ?>/plantilla/js/fastclick.min.js"></script>
                <!-- AdminLTE App -->
                <script src="<?php echo e(URL::to('/')); ?>/plantilla/js/app.min.js"></script>
                <!-- AdminLTE for demo purposes -->
                <script src="<?php echo e(URL::to('/')); ?>/plantilla/js/demo.js"></script>
                <!-- DatePicker -->


<!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.6 -->
    <link rel="stylesheet" href="<?php echo e(URL::to('/')); ?>/plantilla/css/bootstrap.min.css">
    <!--select con buscador-->
    <link rel="stylesheet" href="<?php echo e(URL::to('/')); ?>/plantilla/css/bootstrap-select.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(URL::to('/')); ?>/plantilla/css/font-awesome.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="<?php echo e(URL::to('/')); ?>/plantilla/css/ionicons.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(URL::to('/')); ?>/plantilla/css/AdminLTE.min.css">
     <!-- Jquery-UI -->
    <link rel="stylesheet" href="<?php echo e(URL::to('/')); ?>/plantilla/css/jquery-ui.min.css">
    <!-- DatePicker -->
    <!-- AdminLTE Skins. Choose a skin from the css/skins
    folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="<?php echo e(URL::to('/')); ?>/plantilla/css/_all-skins.min.css">
    <link rel="stylesheet" href="<?php echo e(URL::to('/')); ?>/plantilla/css/breadcrumb.css">
    
    <link rel="stylesheet" href="<?php echo e(URL::to('/')); ?>/plantilla/css/ticket.css">
    
    <link rel="stylesheet" href="<?php echo e(URL::to('/')); ?>/plantilla/css/jquery-nicelabel.css">

    <link rel="stylesheet" href="<?php echo e(URL::to('/')); ?>/plantilla/css/select2.css">
    <link rel="stylesheet" href="<?php echo e(URL::to('/')); ?>/plantilla/js/datatables/datatables.css">
    
    
    <style>
        .code {
            height: 60px !important;
        }
    </style>

<style type="text/css" media="print">
     @media  print {
     #noimpr {display:none;}
      };

      .table-fixed{
  width: 100%;
  background-color: #f3f3f3;
  tbody{
    height:200px;
    overflow-y:auto;
    width: 100%;
    }
  thead,tbody,tr,td,th{
    display:block;
  }
  tbody{
    td{
      float:left;
    }
  }
  thead {
    tr{
      th{
        float:left;
       background-color: #f39c12;
       border-color:#e67e22;
      }
    }
  }
}

    </style>

    <style media="screen">
    
        .tamañomodal {
            width: 90% !important;
        }

        .modal-content {
            -webkit-border-radius: 0px !important;
            -moz-border-radius: 0px !important;
            border-radius: 5px !important;
        }

        .text-derecha {
            text-align: right !important;
        }

        .content {
            padding: 1px !important;
            padding-left: 1px !important;
            padding-right: 1px !important;
        }
        /* Tooltip */
        .tooltip > .tooltip-inner {
            background-color: #614ad9;
            color: #FFFFFF;
            border: 1px solid #000000;
            padding: 5px;
            font-size: 15px;
        }

        /* Tooltip on top */
        .tooltip.top > .tooltip-arrow {
            border-top: 5px solid green;
        }

        /* Tooltip on bottom */
        .tooltip.bottom > .tooltip-arrow {
            border-bottom: 5px solid blue;
        }

        /* Tooltip on left */
        .tooltip.left > .tooltip-arrow {
            border-left: 5px solid red;
        }

        /* Tooltip on right */
        .tooltip.right > .tooltip-arrow {
            border-right: 5px solid black;
        }
    </style>



    <?php echo $__env->yieldContent('css'); ?>
    <?php echo toastr_css(); ?>
    <?php $config = (new \LaravelPWA\Services\ManifestService)->generate(); echo $__env->make( 'laravelpwa::meta' , ['config' => $config])->render(); ?>
</head>
<body class="skin-blue sidebar-mini sidebar-collapse">
<body class="hold-transition skin-blue sidebar-mini">

            <div class="wrapper">
                
             <!-- Navbar -->
            
            <header class="main-header">
                        <a href="<?php echo e(route('home')); ?>" class="logo">
                    <!-- mini logo for sidebar mini 50x50 pixels -->
                        
                        <img src="<?php echo e(asset('imagenes/config/logoepos.png')); ?>" height="30px"width="100px" >
                      
                       
                        </a>
                        <!-- Header Navbar: style can be found in header.less -->
                        <nav class="navbar navbar-static-top">
                            <!-- Sidebar toggle button-->
                            <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </a>
                            <div class="navbar-custom-menu">
                                <ul class="nav navbar-nav">
                                    <?php if(Auth::guest()): ?>
                                    <?php else: ?>
                                        <li class="dropdown">
                                            <a href="#" class="dropdown-toggle" data-toggle="dropdown"
                                               aria-expanded="true"><?php echo e(Auth::user()->name); ?> <?php echo e(Auth::user()->apellido); ?>

                                                <span class="caret"></span></a>
                                            <ul style="background-color: #367fa9; border-color: #367fa9;"
                                                class="dropdown-menu" role="menu">
                                                <li>
                                                    <a style="color: #fff;" href="<?php echo e(url('/logout')); ?>"
                                                       onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                                        Salir</a>
                                                    <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST"
                                                          style="display: none;"><?php echo e(csrf_field()); ?>

                                                    </form>
                                                </li>
                                            </ul>
                                        </li>
                                        <li class="<?php echo e((Request::route()->getName() == 'configuracion') ? 'active' :  ''); ?>" >
                                            <a href="<?php echo e(route('configuracion')); ?>" ><i class="fa fa-gears"></i></a>
                                        </li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </nav>
                    </header>


                     <!-- Navbar -->



                    <!-- Left side column. contains the logo and sidebar -->
                    <aside class="main-sidebar">
                        <!-- sidebar: style can be found in sidebar.less -->
                        <section class="sidebar">
                            <!-- sidebar menu: : style can be found in sidebar.less -->
                            <ul class="sidebar-menu">
                                <?php if(Auth::guest()): ?>
                                    <li class="active treeview">
                                        <a href="#">
                                            <i class="fa fa-dashboard"></i> <span>Inicio</span>
                                            <span class="pull-right-container">
                      <i class="fa fa-angle-left pull-right"></i>
                    </span>
                                        </a>
                                        <ul class="treeview-menu">
                                            <li class="<?php echo e(Request::is('login') ? 'active' :  ''); ?>"><a
                                                        href="<?php echo e(route('login')); ?>"><i class="fa fa-user"></i>Iniciar
                                                    Seción</a></li>
                                            <li class="<?php echo e(Request::is('register') ? 'active' :  ''); ?>"><a
                                                        href="<?php echo e(route('register')); ?>"><i class="fa fa-user-plus"></i>Registrarme</a>
                                            </li>
                                        </ul>
                                    </li>
                                <?php else: ?>
                                    <li class="treeview
                                        <?php echo e((\Request::route()->getName() == 'arqueo.index') ? 'active' : ''); ?>

                                            ">
                                        <a href="<?php echo e(route('arqueo.index')); ?>">
                                            <i class="fa fa-history"></i>
                                            <span>Caja</span>
                                        </a>
                                    </li>
                                    <li class="header"></li>
                                    <li class="treeview <?php echo e((Request::route()->getName() == 'categoria.index') ? 'active' :  ''); ?> ">
                                        <a href="<?php echo e(route('categoria.index')); ?>">
                                            <i class="fa fa-bookmark-o"></i>
                                            <span>Categoría</span>
                                        </a>
                                    </li>
                                    <li class="header"></li>
                                    <li class="treeview <?php echo e((Request::route()->getName() == 'articulo.index') ? 'active' :  ''); ?> ">
                                        <a href="<?php echo e(route('articulo.index')); ?>">
                                            <i class="fa fa-building"></i>
                                            <span>Artículo</span>
                                        </a>
                                    </li>
                                    <li class="header"></li>
                                    <li class="treeview <?php echo e((Request::route()->getName() == 'cliente.index') ? 'active' :  ''); ?> ">
                                        <a href="<?php echo e(route('cliente.index')); ?>">
                                            <i class="fa fa-users"></i>
                                            <span>Clientes</span>
                                        </a>
                                    </li>
                                    <li class="header"></li>
                                    <li class="treeview <?php echo e((Request::route()->getName() == 'proveedor.index') ? 'active' :  ''); ?> ">
                                        <a href="<?php echo e(route('proveedor.index')); ?>">
                                            <i class="fa fa-users"></i>
                                            <span>Proveedor</span>
                                        </a>
                                    </li>
                                    <li class="header"></li>
                                    <li class="treeview <?php echo e((Request::route()->getName() == 'corriente.index') ? 'active' :  ''); ?> ">
                                        <a href="<?php echo e(route('corriente.index')); ?>">
                                            <i class="fa fa-microchip"></i>
                                            <span>Cuenta Corriente</span>
                                        </a>
                                    </li>
                                    <li class="header"></li>
                                    <li class="treeview <?php echo e((Request::route()->getName() == 'venta.index') ? 'active' :  ''); ?> ">
                                        <a href="<?php echo e(route('venta.index')); ?>">
                                            <i class="fa fa-shopping-cart"></i>
                                            <span>Ventas</span>
                                        </a>
                                    </li>
                                    <li class="header"></li>
                                    <li class="treeview <?php echo e((Request::route()->getName() == 'ingreso.index') ? 'active' :  ''); ?> ">
                                        <a href="<?php echo e(route('ingreso.index')); ?>">
                                            <i class="fa fa-briefcase"></i>
                                            <span>Compras</span>
                                        </a>
                                    </li>
                                    <li class="header"></li>
                                    <li class="treeview <?php echo e((Request::route()->getName() == 'devolucion.index') ? 'active' :  ''); ?> ">
                                        <a href="<?php echo e(route('devolucion.index')); ?>">
                                            <i class="fa fa-undo"></i>
                                            <span>Devolución</span>
                                        </a>
                                    </li>
                                    <li class="header"></li>
                                    <li class="treeview <?php echo e((Request::route()->getName() == 'usuarios.index') ? 'active' :  ''); ?> ">
                                        <a href="<?php echo e(route('usuarios.index')); ?>">
                                            <i class="fa fa-user-circle-o"></i>
                                            <span>Usuarios del Sistema</span>
                                        </a>
                                    </li>
                                    <li class="header"></li>
                                <?php endif; ?>
                            </ul>
                        </section>
                        <!-- /.sidebar -->
                    </aside>

                    
                    <!-- Content Wrapper. Contains page content -->
                    <div class="content-wrapper">
                        <section class="content">
                            <?php echo $__env->yieldContent('content'); ?>
                        </section>
                        <!-- /.content -->
                    </div>
                    <!-- /.content-wrapper -->
                
                    <footer class="main-footer" id="noimpr">
                        <div class="pull-right hidden-xs">
                            <b>Version</b> 2.0.0
                        </div>
                       
                            <strong>Copyright &copy; 2021 <a href="#">LyL Sistemas</a>.</strong>
                     
                   
    
                    </footer>

                    <div class="control-sidebar-bg"></div>
                    </div>

               
               

                
                <?php echo toastr_js(); ?>
                <?php echo app('toastr')->render(); ?>

                <script src="<?php echo e(URL::to('/')); ?>/plantilla/js/jquery.plainmodal.min.js"></script>
                <script src="<?php echo e(URL::to('/')); ?>/plantilla/js/jquery-ui.min.js"></script>
                <script src="<?php echo e(URL::to('/')); ?>/plantilla/js/modalcliente.js"></script>
                <script src="<?php echo e(URL::to('/')); ?>/plantilla/js/graficas.js"></script>
                <script src="<?php echo e(URL::to('/')); ?>/plantilla/js/graficas2.js"></script>
                <script src="<?php echo e(URL::to('/')); ?>/plantilla/js/morris.min.js"></script>
                <script src="<?php echo e(URL::to('/')); ?>/plantilla/js/jquery.nicelabel.js"></script>
                <script src="<?php echo e(URL::to('/')); ?>/plantilla/js/select2.js"></script>
                <script src="<?php echo e(URL::to('/')); ?>/plantilla/js/datatables/datatables.js"></script>
                <script src="https://cdn.datatables.net/buttons/1.7.0/js/dataTables.buttons.min.js"></script>
                <script src="https://cdn.datatables.net/buttons/1.7.0/js/buttons.html5.min.js"></script>
                <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
                <script src="<?php echo e(URL::to('/')); ?>/plantilla/js/Impresora.js"></script>
                <?php echo $__env->yieldContent('js'); ?>
                </body>
</html>
<?php /**PATH C:\laragon\www\sisventa\resources\views/layouts/app.blade.php ENDPATH**/ ?>