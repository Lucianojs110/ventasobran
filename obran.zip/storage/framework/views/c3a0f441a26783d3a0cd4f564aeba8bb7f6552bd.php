<?php $__env->startSection('content'); ?>
    <style>
        .rect-checkbox {
            float: left;
            margin-left: 130px;
        }

        .span {
            margin-left: -180px;
        }
    </style>
    <section class="content">
        <div class="box">
            <div class="box-header with-border">
                <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                        <h3>Nueva Ingreso</h3>
                        <?php if(count($errors)>0): ?>
                            <div class="alert alert-danger alert-dismissible">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <?php echo Form::open(['route' => 'ingreso.store', 'method'=>'POST', 'autocomplete' => 'off']); ?>

                <?php echo e(Form::token()); ?>


                <div class="row">
                    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                        <div class="form-group">
                            <label for="proveedor">Proveedor</label>
                            <select autofocus name="idproveedor" required class="form-control selectpicker" id="idproveedor"
                                    data-live-search="true">
                                <option></option>
                                <?php $__currentLoopData = $personas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $persona): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($persona->idpersona); ?>"><?php echo e($persona->nombre); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                        <div class="form-group">
                            <label>Tipo Comprobante:</label>
                            <input type="text" readonly value="Ingreso" name="tipo_comprobante" class="form-control"
                                   placeholder="Numero Comprobante">
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                        <div class="form-group">
                            <label for="num_comprobante">Número Comprobante:</label>
                            <?php if($ing == '1'): ?>
                                <input type="text" readonly value="0-0" name="num_comprobante" class="form-control"
                                       placeholder="Numero Comprobante">
                            <?php else: ?>
                                <input type="text" readonly value="0-<?php echo e($ing->idingreso); ?>" name="num_comprobante"
                                       class="form-control" placeholder="Numero Comprobante">
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="">
                    <div class="panel panel-primary">
                        <div class="panel-body">
                            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                                <div class="form-group">
                                    <label>Articulo</label>
                                    <select autofocus name="pidarticulo" class="form-control selectpicker"
                                            id="pidarticulo" data-live-search="true">
                                        <option value="0"></option>
                                        <?php $__currentLoopData = $articulos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $articulo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($articulo->idarticulo); ?>"><?php echo e($articulo->codigo); ?> <?php echo e($articulo->nombre); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
                                <div class="form-group">
                                    <label for="cantidad">Cantidad</label>
                                    <input type="number" step="0.01" name="pcantidad" id="pcantidad"
                                           class="form-control" placeholder="Cantidad">
                                </div>
                            </div>
                            <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
                                <div class="form-group">
                                    <label for="precio_compra">Precio Compra</label>
                                    <input type="number" name="pprecio_compra" id="pprecio_compra" class="form-control"
                                           placeholder="Precio Compra">
                                </div>
                            </div>
                            <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
                                <div class="form-group">
                                    <label for="precio_venta">Precio Venta</label>
                                    <input type="number" name="pprecio_venta" id="pprecio_venta" class="form-control"
                                           placeholder="Precio Venta">
                                </div>
                            </div>
                            <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
                                <div class="form-group">
                                    <label for="">
                                        <hr></label>
                                    <button type="button" id="bt-add" class="btn btn-primary btn-xs"><i class="fa fa-check"></i> Agregar</button>
                                </div>
                            </div>
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 table-responsive">
                                <table id="detalles" class="table">
                                    <thead style="background-color: #A9D0F5">
                                    <th>Opciones</th>
                                    <th>Artículos</th>
                                    <th>Cantidad</th>
                                    <th>Precio Compra</th>
                                    <th>Precio Venta</th>
                                    <th>Subtotal</th>
                                    </thead>
                                    <tfoot>
                                    <th>TOTAL</th>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                    <th><h4 id="total">$ 0.00</h4></th>
                                    </tfoot>
                                    <tbody>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div class="container-fluid" id="guardar">
                        <div class="form-group">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"></input>
                            <button class="btn btn-primary pull-left btn-xs btn-flat" type="submit"><i class="fa fa-save"></i> Guardar </button>
                            <button class="btn btn-danger pull-right btn-xs btn-flat" type="reset"><i class="fa fa-window-close"></i> Cancelar</button>
                        </div>
                    </div>
                </div>
                <?php echo Form::close(); ?>

            </div>
        </div>
    </section>
<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function () {
            $('#bt-add').click(function () {
                agregar();
            });
        });
        var cont = 0;
        total = 0;
        subtotal = [];
        total = 0;
        $("#guardar").hide();

        function agregar() {
            idarticulo = $("#pidarticulo").val();
            articulo = $("#pidarticulo option:selected").text();
            cantidad = $("#pcantidad").val();
            precio_compra = $("#pprecio_compra").val();
            precio_venta = $("#pprecio_venta").val();


            if (idarticulo != "" && cantidad != "" && cantidad > 0 && pprecio_compra != "" && precio_venta != "") {
                subtotal[cont] = (cantidad * precio_compra);
                total = total + subtotal[cont];
                var fila = '<tr class="selected" id="fila' + cont + '"><td><button type="button" class="btn btn-danger btn-xs" onclick="eliminar(' + cont + ');">X</button></td><td><input type="hidden" name="idarticulo[]" value="' + idarticulo + '">' + articulo + '</td><td><input readonly type="number" name="cantidad[]" value="' + cantidad + '"></td><td><input readonly type="number" name="precio_compra[]" value="' + precio_compra + '"></td><td><input readonly type="number" name="precio_venta[]" value="' + precio_venta + '"></td><td>' + subtotal[cont] + '</td></tr>';
                cont++;
                limpiar();
                $('#total').html("$ " + total);
                evaluar();
                $('#detalles').append(fila);

            } else {
                alert("Error al ingresar el detalle del ingreso, revise los datos del artículo");
            }
        }

        function limpiar() {
            $('#pcantidad').val("");
            $('#pstock').val("");
            $('#pdescuento').val("");
            $('#pprecio_venta').val("");
            $('#pprecio_compra').val("");
            $('#pidarticulo').selectpicker('val', '0');
        }

        function evaluar() {
            if (total > 0) {
                $("#guardar").show();
            } else {
                $("#guardar").hide();
            }
        }

        function eliminar(index) {
            total = total - subtotal[index];
            $("#total").html("$ " + total);
            $("#fila" + index).remove();
            evaluar();
        }
    </script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\sisventanew\resources\views\compras\ingreso\create.blade.php ENDPATH**/ ?>