<?php $__env->startSection('content'); ?>
<style>
  .loader {
    display: none;
    position: fixed;
    left: 0px;
    top: 0px;
    width: 100%;
    height: 100%;
    z-index: 9999;
    background: url('<?php echo e(asset('imagenes/loading2.gif')); ?>') 50% 50% no-repeat rgb(249, 249, 249);
    opacity: .8;
  }

  .cargando {
    position: fixed;
    font-size: 25px;
    left: 30%;
    top: 60%;
    width: 100%;
    height: 100%;
    z-index: 9998;

  }
</style>

<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<div class="loader" id="loader">
  <div class="cargando"><b> Se esta registrando su factura. Aguarde un momento... </b></div>
</div>
<div class="container" style=" padding:20px;">
  <div class="col-md-3">
  </div>
  <div class="col-md-7" style="background-color: #fff; margin-left:30px;  padding:20px">

    <table>
      <tbody>
        <tr>
          <th WIDTH="400" HEIGHT="40" style="border: 1px solid; text-align: center">

            <img src="<?php echo e(asset('imagenes/config/'.$config->imagen)); ?>" height="80%"
              width="45%"><br>
            <span>de: <?php echo e($config->razon_social); ?></span>
          </th>
          <th WIDTH="100" style="border: 1px solid; text-align: center">

            <?php if($venta->tipo_comprobante=='Factura C'): ?>
              <span style="font-size: 50px; font-family: sans-serif">C</span><br>
              <span>cod. 11</span>
            <?php elseif($venta->tipo_comprobante=='Factura A'): ?>
              <span style="font-size: 50px; font-family: sans-serif">A</span><br>
              <span>cod. 11</span>
            <?php else: ?>
              <span style="font-size: 50px; font-family: sans-serif">B</span><br>
              <span>cod. 06</span>
            <?php endif; ?>

          <th WIDTH="400" style="border: 1px solid; text-align: center">
            <div id="numero">
              <span style="font-size: 20px; font-family: sans-serif">FACTURA </span><br>
              <span>Nº: <?php echo e($venta->num_comprobante); ?></span><br>
              Fecha: <?php echo e($newDate = date("d-m-Y", strtotime($venta->fecha_hora))); ?>


            </div>
          </th>
        </tr>
      </tbody>

    </table>
    <table>
      <tbody>
        <tr style="border: 1px solid">
          <th WIDTH="500" HEIGHT="50" style="padding: 10px; font-family: sans-serif">
            Direccion: <?php echo e($config->direccion); ?><br>
            <?php if($config->impuesto == 11): ?>
              Iva: Monotributo <br>
            <?php else: ?>
              Iva: Responsable Inscripto <br>
            <?php endif; ?>
            Cuit: <?php echo e($config->dni); ?><br>
          </th>
          <th WIDTH="500" style=" padding: 10px; font-family: sans-serif">
            Ingresos Brutos: <?php echo e($config->ingresos_brutos); ?><br>
            Telefono: <?php echo e($config->telefono); ?><br>
            Email: <?php echo e($config->correo); ?><br>
          </th>

        <tr style="border: 1px solid">

          <th WIDTH="500" HEIGHT="50" style="padding: 10px; font-family: sans-serif">
            Cliente: <?php echo e($venta->cliente->nombre); ?> <br>
            <?php if($venta->cliente->num_documento=='0'): ?>
              Cuit:<br>
            <?php else: ?>
              Cuit: <?php echo e($venta->cliente->num_documento); ?> <br>
            <?php endif; ?>
            Cond. IVA: <br>

          </th>
          <th WIDTH="500" style=" padding: 10px; font-family: sans-serif">
            Domicilio: <?php echo e($venta->cliente->direccion); ?> <br>
            Telefono: <?php echo e($venta->cliente->telefono); ?> <br>
            Cond. Venta: CONTADO
          </th>
  </div>
  </tr>
  </tbody>
  </table>



  <table style="font-family: sans-serif; border: 1px solid; padding: 10px" id="detalle">
    <thead>
      <tr>
        <th style="padding: 3px; border: 1px solid; background-color:#CCD1D1">Articulo</th>
        <th style="padding: 3px; border: 1px solid; background-color:#CCD1D1">Cant.</th>
        <th style="padding: 3px; border: 1px solid; background-color:#CCD1D1">P. Unit.</th>
        <th style="padding: 3px; border: 1px solid; background-color:#CCD1D1">Desc.</th>
        <th style="padding: 3px; border: 1px solid; background-color:#CCD1D1">Subtotal</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $venta->detalles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $det): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td style="width: 60%; text-align: left; padding: 3px;" class="text-right"><?php echo e($det->articulo->nombre); ?>

          </td>
          <td style="width: 15%; text-align: left; padding: 3px;" class="text-right"><?php echo e($det->cantidad); ?></td>
          <td style="width: 15%; text-align: left; padding: 3px;" class="text-right"><?php echo e($det->precio_venta); ?></td>
          <td style="width: 15%; text-align: left; padding: 3px;" class="text-right"><?php echo e($det->descuento); ?></td>
          <td style="width: 15%; text-align: left">
            <?php echo e($det->cantidad*$det->precio_venta-$det->descuento); ?></td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php if($venta->monto_porcentaje != 0): ?>
        <tr>

          <td>Monto de interés por crédito</td>
          <td class="text-derecha">1</td>
          <td class="text-derecha">$<?php echo e($venta->monto_porcentaje); ?>

            (<?php echo e($venta->porcentaje_credito); ?>%)
          </td>
          <td class="text-derecha">0.00</td>
          <td class="text-derecha">$<?php echo e($venta->monto_porcentaje); ?></td>
        </tr>
      <?php endif; ?>
    </tbody>

  </table>
  <h3>Importe total: $<?php echo e($venta->total_venta); ?></h3>
  <br>


  <br>

  <div class="row">

    <div class="col-sm-12">
      <div id="cae">
        <table>
          <tbody>
            <?php if($venta->cae!=null): ?>
              <tr>
                <th WIDTH="250" HEIGHT="100">

                  <img src="https://chart.googleapis.com/chart?chs=150x150&cht=qr&chl=<?php echo e($venta->codigoQr); ?>">

                </th>
                <th WIDTH="600" HEIGHT="100">
                  <img src="<?php echo e(asset('imagenes/config/logo_afip.png')); ?>" height="40%"
                    width="40%"><br>
                  <span style="font-size: 15px">Comprobante Autorizado</span><br>
                  <span style="font-size: 10px">Esta administración federal no se responsabiliza por los datos
                    ingresados en el detalle de la operación</span>
                </th>
                <th WIDTH="300" HEIGHT="100">
                  <b>N° CAE: </b> <?php echo e($venta->vtocae); ?> <br>
                  Fecha Vto. CAE:
                  <?php echo e($newDate = date("d-m-Y", strtotime($venta->vtocae))); ?>

                </th>
            <?php endif; ?>
            </tr>
          </tbody>
        </table>
      </div>

    </div>

    <div class="col-md-3">
    </div>
    <div class="row" id="noimpr">
      <div id="reload">
        <div class="col-sm-12">
          <div class="col-sm-6" id="btncae">
            <?php if($venta->cae==null): ?>
              <button id="btn-sol-cae" class="btn btn-primary btn-xs">Solicitar CAE</button>
            <?php endif; ?>
          </div>
          <div class="col-sm-6" id="btnimp" style="text-align:right">
            <?php if($venta->cae!=null): ?>
              <button type="button" class="btn btn-primary btn-xs" onclick="javascript:window.print()"><i
                  class="fa fa-print"></i>Imprimir</button>
              <button type="button" id="tprint" class="btn btn-primary btn-xs"><i class="fa fa-print"></i> Imprimir
                ticket</button>
            <?php endif; ?>
            <input type="hidden" class="form-control" id="idventa" value="<?php echo e($venta->idventa); ?>">
          </div>
        </div>
      </div>
    </div>



  </div>
</div>
</div>

<!-- inicio ticket -->

<div class="col-md-6" id="ticket" style="display: none">
  <table>
    <tbody>
      <tr>
        <div style="text-align:center; font-family: Arial">
          <b> <?php echo e($config->nombre); ?> </b> <br>
          <?php echo e($config->lema); ?> <br>
          <hr>
        </div>
        <div style="text-align:left; font-size:12; font-family: Arial">
          Razon Social: <?php echo e($config->razon_social); ?><br>
          Cuit: <?php echo e($config->dni); ?><br>
          Ingresos Brutos: <?php echo e($config->ingresos_brutos); ?><br>
          <?php if($config->impuesto == 11): ?>
            Iva: Monotributo <br>
          <?php else: ?>
            Iva: Responsable Inscripto <br>
          <?php endif; ?>

          Direccion: <?php echo e($config->direccion); ?><br>
          <?php if($venta->tipo_comprobante=='Factura C'): ?>
            Factura: C<br>

          <?php elseif($venta->tipo_comprobante=='Factura A'): ?>
            Factura: A<br>

          <?php else: ?>
            Factura: B<br>
          <?php endif; ?>
          Nº: <?php echo e($venta->num_comprobante); ?><br>
          Fecha: <?php echo e($newDate = date("d-m-Y", strtotime($venta->fecha_hora))); ?><br>
        </div>
        <div style="text-align:center; font-family: Arial">
          <hr>
        </div>
        <div style="text-align:left; font-size:12; font-family: Arial">
          Cliente: <?php echo e($venta->cliente->nombre); ?> <br>
          <?php if($venta->cliente->num_documento=='0'): ?>
          <?php else: ?>
            Cuit: <?php echo e($venta->cliente->num_documento); ?> <br>
          <?php endif; ?>
          Cond. Venta: CONTADO
        </div>
      </tr>
</div>


</tbody>
<hr>
</table>
<div>
  <div style="text-align:left; font-size:8px; font-family: Arial">
    <table class="table bordered" id="detalle">
      <thead>
        <tr>
          <th style="width: 100%; text-align: left; font-size:11px; font-family: Arial">Cant.</th>
          <th style="width: 100%; text-align: left; font-size:11px; font-family: Arial">Art</th>
          <th style="width: 100%; text-align: left; font-size:11px; font-family: Arial">P. Unit</th>
          <th style="width: 100%; text-align: left; font-size:11px; font-family: Arial">STotal</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $venta->detalles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $det): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td style="width: 100%; text-align: left; font-size:11px; font-family: Arial"><?php echo e($det->cantidad); ?>x</td>
            <td style="width: 100%; text-align: left; font-size:11px; font-family: Arial">
              <?php echo e($det->articulo->nombre); ?></td>
            <td style="width: 100%; text-align: left; font-size:11px; font-family: Arial">$<?php echo e($det->precio_venta); ?>

            </td>
            <td style="width: 100%; text-align: left; font-size:11px; font-family: Arial">
              $<?php echo e($det->cantidad*$det->precio_venta-$det->descuento); ?></td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>

      <tfoot>

        <tr>

          <th class="text-left"><b> Total</b></th>
          <th class="text-left" id="total">$<?php echo e($venta->total_venta); ?></th>
        </tr>
      </tfoot>
    </table>
    <hr>

    <div style="width: 100%; text-align: center; font-size:10; font-family: Arial">
      <?php if($venta->cae!=null): ?>
        <img src="https://chart.googleapis.com/chart?chs=150x150&cht=qr&chl=<?php echo e($venta->codigoQr); ?>"><br>
        CAE: <?php echo e($venta->cae); ?> <br>
        Vto. CAE: <?php echo e($newDate = date("d-m-Y", strtotime($venta->vtocae))); ?><br>
      <?php endif; ?>

    </div>
  </div>
</div>


<!-- fin tiket -->

<?php $__env->startSection('js'); ?>
<script>
  $(document).ready(function () {
    $("#btn-sol-cae").click(function () {
      solicitar_cae()
    });

    $('#tprint').click(function () {
      imprimir();
    });
  });

  function solicitar_cae() {
    $.ajax({
      headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
      },
      type: "POST",
      url: "<?php echo e(route('solicitarcae')); ?>",
      dataType: "json",
      beforeSend: function () {
        document.getElementById("loader").style.display = "block";
      },
      data: {
        idventa: $("#idventa").val(),
      },
      success: function (data) {
        document.getElementById("loader").style.display = "none";
        $("#cae").load(" #cae");
        $("#numero").load(" #numero");
        $("#reload").load(" #reload");
        toastr.success("Comprobante registrado")
        console.log(data)
      },
      error: function (data) {
        toastr.warning("Algo ha salido mal al conectarse al webserver")
        alert('No se realizo la operacion. Respuesta del servidor: ' + data.responseJSON.message)
      },

    });
    return false;
  }


  function imprimir() {


    mywindow = window.open("", "ventana1", "height=300,width=300");


    mywindow.document.write('<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 table-responsive">' + document
      .getElementById('ticket').innerHTML + '</div>');

    mywindow.document.write('</body></html>');
    mywindow.document.close(); // necessary for IE >= 10
    mywindow.focus(); // necessary for IE >= 10*/


    mywindow.window.print();

    function close() {

      mywindow.close();

    }
    setTimeout(close(), 1500);



  }
</script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sisventaobran\resources\views/ventas/venta/tickes.blade.php ENDPATH**/ ?>