<div class="modal modal-info fade in" id="modal-editar-<?php echo e($art->idarticulo); ?>">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span></button>
                <h4 class="modal-title"><i data-toggle="tooltip" title="Editar artículo: <?php echo e($art->nombre); ?>" class="fa fa-edit"></i> Editar artículo: <?php echo e($art->nombre); ?></h4>
            </div>
            <?php if(count($art->detalleIngresos) != 0): ?>
                <?php $__currentLoopData = $art->detalleIngresos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $det): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($loop->last): ?>
                        <?php
                            $precio_compra = $det->precio_compra;
                            $precio_venta = $det->precio_venta;
                        ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <?php
                    $precio_compra = 0;
                    $precio_venta = 0;

                ?>
            <?php endif; ?>
            <div style="overflow-y: auto !important;background-color: #ffffff !important;color: black !important;" class="modal-body">
                <?php echo Form::model($art,['route'=>['articulo.update', $art->idarticulo] , 'method'=>'PATCH', 'files'=>'true', 'id'=>'edit-'.$art->idarticulo] ); ?>

                <?php echo e(Form::token()); ?>

                    <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                        <div class="form-group">
                            <label for="nombre">Nombre</label>
                            <input type="text" value="<?php echo e($art->nombre); ?>" required name="nombre" class="form-control" placeholder="Nombre del artículo...">
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                        <div class="form-group">
                            <label>Categoría</label>
                            <select name="idcategoria" class="form-control">
                                <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($art->idcategoria == $cat->idcategoria): ?>
                                        <option selected value="<?php echo e($cat->idcategoria); ?>"><?php echo e($cat->nombre); ?></option>
                                    <?php else: ?>
                                        <option value="<?php echo e($cat->idcategoria); ?>"><?php echo e($cat->nombre); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                        <div class="form-group">
                            <label for="codigo">Codígo</label>
                            <input type="text"  name="codigo"  value="<?php echo e($art->codigo); ?>" class="form-control" placeholder="Codígo del artículo...">
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                        <div class="form-group">
                            <label for="stock">Stock</label>
                            <input type="text" disabled required class="form-control" placeholder="El stock debe cargarse en el INGRESO.">
                            <input type="hidden" required  value="<?php echo e($art->stock); ?>" name="stock" class="form-control">
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                        <div class="form-group">
                            <label for="descripcion">Descripción</label>
                            <input type="text" name="descripcion"  value="<?php echo e($art->descripcion); ?>" class="form-control" placeholder="Descripción del artículo...">
                        </div>
                    </div>

                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                        <div class="form-group">
                            <label for="imagen">Imagen</label>
                            <input type="file" name="imagen" onchange="control(this)" accept="image/*" class="form-control">
                        </div>
                    </div>
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                            <label for="">Precio Compra</label>
                            <input type="number" name="precio_compra" value="<?php echo e($precio_compra); ?>" class="form-control">
                        </div>

                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                            <label for="">Precio Venta</label>
                            <input type="number" name="precio_venta" value="<?php echo e($precio_venta); ?>" class="form-control">
                        </div>
                </div>
                <?php echo Form::close(); ?>

            </div>
            <div class="modal-footer">
                <button type="reset" class="btn btn-outline pull-left  btn-xs" data-dismiss="modal"> <i class="fa fa-window-close"></i> Cancelar</button>
                <button type="submit" form="edit-<?php echo e($art->idarticulo); ?>" class="btn btn-outline  btn-xs"> <i class="fa fa-save"></i> Guardar</button>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div><?php /**PATH D:\xampp\htdocs\sisventanew\resources\views/almacen/articulo/modal-editar.blade.php ENDPATH**/ ?>