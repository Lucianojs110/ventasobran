<?php $__env->startSection('content'); ?>
    <div class="login-box">
         <div class="login-box-msg">
            <h2><b>E</b>POS</h2>
            <div class="login-box-body">
                <p class="login-box-msg">Ingresa tus datos para entrar al Sistema</p>
                        <form id="login-form" action="<?php echo e(route('login')); ?>" method="POST" role="form" novalidate="">
                        <?php echo e(csrf_field()); ?>


                        <?php if(Session::has('message')): ?>
                        <div class="alert alert-danger alert-dismissible" role="alert">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <?php echo e(Session::get('message')); ?>

                        </div>
                       <?php endif; ?>
                        
                            <div class="has-feedback <?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                                <label for="email">Correo</label>
                                <input type="email" for="email" class="form-control" name="email" id="email" placeholder="Ingrese su correo " required value="<?php echo e(old('email')); ?>"  >
                                <?php if($errors->has('email')): ?>
                                    <span class="has-error">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>

                            <div class="has-feedback">
                                <label class="control-label" for="inputError1" for="password">Contraseña</label>
                                <input type="password" class="form-control" name="password" id="password" placeholder="Tu Contraseña" required>
                                <?php if($errors->has('password')): ?>
                                    <span class="has-error">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>


                        <div class="form-group">
                            <label>Sucursal</label>
                            <select name="sucursal" class="form-control">
                                <?php $__currentLoopData = $sucursal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sucursales): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($sucursales->id); ?>"><?php echo e($sucursales->nombre); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

               


                       

                            <div class="has-feedback">
                                  <label>
                                    <input  name="remember" type="checkbox" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                                     Recordarme  </label>
                            </div>
                            <div class="has-feedback">
                                <button type="submit" class="btn btn-block btn-primary">Entrar</button>
                            </div>
                            <div class="has-feedback">
                                <p class="text-muted text-xs-center">¿No tienes una cuenta?<a href="<?php echo e(route('register')); ?>"> Registrate!</a></p>
                            </div>
                        </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sisventaobran\resources\views/auth/login.blade.php ENDPATH**/ ?>