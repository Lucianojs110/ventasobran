<?php $__env->startSection('content'); ?>
	<section class="content">
		<div class="box">
			<div class="box-header with-border">
				<div class="row">
					<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
						<div class="form-group">
							<label for="proveedor">Cliente</label>
							<p><?php echo e($devolucion->nombre); ?></p>
						</div>
					</div>
					<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
						<div class="form-group">
							<label for="fecha_hora">Fecha de la devolución</label>
							<p><?php echo e(date("d-m-Y", strtotime($devolucion->fecha_devolucion))); ?></p>
						</div>
					</div>

					<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
						<div class="form-group">
							<label>Número de Comprobante Devolución</label>
							<p><?php echo e($devolucion->num_comprobante); ?></p>
						</div>
					</div>
					<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
						<div class="form-group">
							<label for="num_comprobante">Número de Factura</label>
							<p><?php echo e($devolucion->num_factura); ?></p>
						</div>
					</div>
				</div>
				<div class="panel panel-primary">
					<div class="panel-body">
						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12  table-responsive">
							 <table class="table table-striped table-bordered table-condensed table-hover">
								<thead style="background-color: #A9D0F5">
									<th>Artículos</th>
									<th>Cantidad</th>
									<th>Estado</th>
									<th>Descripción</th>
								</thead>
								<tbody>
									<?php $__currentLoopData = $detalles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $det): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<tr>
											<td><?php echo e($det->nombre); ?></td>
											<td><?php echo e($det->cantidad); ?></td>
											<td>
												<?php if($det->sube_resta == 'sumar'): ?>
												    Se sumo en el Stock
												<?php else: ?>
													No se sumo ni se resto
												<?php endif; ?>
											</td>
											<td><?php echo e($det->descripcion); ?></td>
										</tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
				<div>
					<a target="_blank" href="<?php echo e(route('devolucion.pdf', $devolucion->iddevolucion)); ?>"><button class="btn btn-info btn-xs"> <i class="fa fa-print"></i> Descargar PDF</button></a>
				</div>
			</div>
		</div>
	</section>
	<?php echo Form::close(); ?>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\sisventanew\resources\views\ventas\devolucion\show.blade.php ENDPATH**/ ?>