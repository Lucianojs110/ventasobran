<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="box">
            <div class="box-header with-border">

                <div class="row">
                    <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
                        <h3>Listado de Proveedores
                            <button  data-toggle="modal" data-target="#modal-agregar-proveedor" class="btn btn-xs btn-success"><i data-toggle="tooltip" title="Agregar Cliente" class="fa fa-plus-circle"></i></button>
                            <a href="<?php echo e(route('pdf.proveedor')); ?>" class="btn btn-primary btn-xs" ><i data-toggle="tooltip" title="Imprimir Proveedores"  class="fa fa-fw fa-print"></i></a>
                        </h3>
                    </div>
                </div>
                <?php echo $__env->make('compras.proveedor.modal-agregar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php $__currentLoopData = $personas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('compras.proveedor.modal-editar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo $__env->make('compras.proveedor.modal-borrar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo $__env->make('compras.proveedor.modal-show', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="table">
                            <table id="cli" class="table table-striped table-bordered table-condensed table-hover">
                                <thead>
                                <th>Nombre</th>
                                <th>Documentp</th>
                                <th>Teléfono</th>
                                <th>Email</th>
                                <th>Opciones</th>
                                </thead>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready(function () {
            $('[data-toggle="tooltip"]').tooltip();
        });

        $('#cli').DataTable({
            processing: true,
            serverSide: true,
            iDisplayLength: 10,
            order: [[0, "desc"]],
            ajax: "<?php echo e(route('proveedor.tabla')); ?>",
            columns: [
                {data: 'nombre', name: 'nombre'},
                {data: 'documento', name: 'documento'},
                {data: 'telefono', name: 'telefono'},
                {data: 'email', name: 'email'},
                {data: 'opcion', name: 'opcion', orderable: false, searchable: false}
            ],
            "language": {
                "url": "<?php echo e(URL::to('/')); ?>/admin/Spanish.json"
            }
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sisventaobran\resources\views/compras/proveedor/indexx.blade.php ENDPATH**/ ?>