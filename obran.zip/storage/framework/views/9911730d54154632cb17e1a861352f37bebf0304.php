<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="box">
            <div class="box-header with-border">
                <div class="container-fluid">
                    <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
                        <div class="form-group">
                            <label for="proveedor">Cliente</label>
                            <p><?php echo e($venta->cliente->nombre); ?></p>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
                        <div class="form-group">
                            <label for="fecha_hora">Fecha</label>
                            <p><?php echo e(date("d-m-Y", strtotime($venta->fecha_hora))); ?></p>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
                        <div class="form-group">
                            <label for="fecha_hora">Vendedor</label>
                            <p><?php echo e($venta->usuario->name); ?></p>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
                        <div class="form-group">
                            <label>Tipo Comprobante</label>
                            <p><?php echo e($venta->tipo_comprobante); ?></p>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
                        <div class="form-group">
                            <label for="num_comprobante">Número Comprobante</label>
                            <p><?php echo e($venta->num_comprobante); ?></p>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
                        <div class="form-group">
                            <label for="num_comprobante">Total Venta</label>
                            <p><?php echo e($venta->total_venta); ?> $</p>
                        </div>
                    </div>
                </div>
                <div class="panel panel-primary">
                    <div class="panel-body">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12  table-responsive">
                            <table class="table table-bordered">
                                <table id="detalles"
                                       class="table table-striped table-bordered table-condensed table-hover">
                                    <thead style="background-color: #A9D0F5">
                                    <th>DD-MM-AAAA</th>
                                    <th>Artículos</th>
                                    <th>Codigo</th>
                                    <th>Cantidad</th>
                                    <th>Precio Venta</th>
                                    <th>Descuento</th>
                                    <th>Subtotal</th>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $venta->detalles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $det): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e(date("d-m-Y", strtotime($det->created_at))); ?></td>
                                            <td><?php echo e($det->articulo->nombre); ?></td>
                                            <td><?php echo e($det->articulo->codigo); ?></td>
                                            <td><?php echo e($det->cantidad); ?></td>
                                            <td><?php echo e($det->precio_venta); ?>$</td>
                                            <td><?php echo e(number_format($det->descuento, 2, '.', '')); ?>$
                                            </td>
                                            <td><?php echo e(number_format($det->cantidad*$det->precio_venta-$det->descuento, 2, '.', '')); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($venta->monto_porcentaje != 0): ?>
                                        <tr>
                                            <td><?php echo e(date("d-m-Y", strtotime($venta->fecha_hora))); ?></td>
                                            <td>Monton de interes por credito</td>
                                            <td class="text-derecha">1</td>
                                            <td class="text-derecha"><?php echo e($venta->monto_porcentaje); ?>$
                                                (<?php echo e($venta->porcentaje_credito); ?>%)
                                            </td>
                                            <td class="text-derecha">0.00$</td>
                                            <td class="text-derecha"><?php echo e($venta->monto_porcentaje); ?>$</td>
                                        </tr>
                                    <?php endif; ?>
                                    </tbody>
                                    <tbody>
                                    <th>TOTAL</th>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                    <th class="text-derecha"><h4><?php echo e(number_format($venta->total_venta, 2, '.', '')); ?>

                                            $</h4></th>
                                    </tbody>
                                    <tbody>
                                    <th>PAGA</th>
                                    <th></th>
                                    <th class="text-derecha"><h5>Debito: <?php echo e($venta->tarjeta_debito); ?> $</h5></th>
                                    <th class="text-derecha"><h5>Credito: <?php echo e($venta->tarjeta_credito); ?> $</h5></th>
                                    <th class="text-derecha"><h5>Efectivo: <?php echo e($venta->paga); ?> $</h5></th>
                                    <th class="text-derecha"><h4>
                                            Total: <?php echo e($venta->paga + $venta->tarjeta_credito + $venta->tarjeta_debito + $venta->monto_porcentaje); ?>

                                            $</h4></th>

                                    </tbody>
                                    <tbody>
                                    <th>CAMBIO</th>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                    <th class="text-derecha">
                                        <h4><?php echo e(number_format($venta->paga + $venta->tarjeta_credito + $venta->tarjeta_debito - $venta->total_venta + $venta->monto_porcentaje, 2, '.', '')); ?></h4>
                                    </th>
                                    </tbody>
                                </table>
                        </div>
                    </div>
                </div>
                <div>
                    <a href="<?php echo e(route('pdf.venta',$venta->idventa)); ?>" class="btn btn-xs btn-info pull-left"><i class="fa fa-print"></i> Descargar PDF
                    </a>
                    <a href="" data-target="#modal-devo" data-toggle="modal" class="btn btn-xs btn-success pull-right">
                        <i class="fa fa-undo"></i> Devolución de Productos
                    </a>
                </div>
            </div>
        </div>
    </section>
    <?php echo $__env->make('ventas.venta.modal-devolucion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sisventa\resources\views/ventas/venta/show.blade.php ENDPATH**/ ?>