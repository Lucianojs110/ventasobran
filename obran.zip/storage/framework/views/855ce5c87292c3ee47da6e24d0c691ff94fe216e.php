<?php $__env->startSection('content'); ?>

<div  style="text-align: center; background-color: white; padding: 200px">
    <img src="<?php echo e(asset('imagenes/config/offline.png')); ?>">
    <h1 style="color:gray;">No esta conectado a internet.</h1>
    <h3 style="color:gray;">Presione (F5) para actualizar .</h3>

</div>    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\sisventa\resources\views/vendor/laravelpwa/offline.blade.php ENDPATH**/ ?>