<div class="modal modal-info fade in" id="modal-editar-<?php echo e($cli->idpersona); ?>">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span></button>
                <h4 class="modal-title"><i data-toggle="tooltip" title="Editar cliente: <?php echo e($cli->nombre); ?>"
                                           class="fa fa-edit"></i> Editar cliente: <?php echo e($cli->nombre); ?></h4>
            </div>
            <div style="overflow-y: auto !important;background-color: #ffffff !important;color: black !important;"
                 class="modal-body">
                <?php echo Form::model($cli,['route'=>['cliente.update', $cli->idpersona] , 'method'=>'PATCH', 'files'=>'true', 'id'=>'edit-'.$cli->idpersona] ); ?>

                <?php echo e(Form::token()); ?>

                <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                        <div class="form-group">
                            <label for="nombre">Nombre</label>
                            <input type="text" value="<?php echo e($cli->nombre); ?>" required name="nombre" class="form-control" placeholder="Nombre...">
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                        <div class="form-group">
                            <label for="nombre">Dirección</label>
                            <input type="text" required name="direccion" value="<?php echo e($cli->direccion); ?>" class="form-control"
                                   placeholder="Dirección...">
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                        <div class="form-group">
                            <label>Documento</label>
                            <select name="tipo_documento" class="form-control">
                                <option <?php echo e($cli->tipo_documento == 'DNI' ? 'selected' : ''); ?> value="DNI">DNI</option>
                                <option <?php echo e($cli->tipo_documento == 'RUC' ? 'selected' : ''); ?> value="RUC">RUC(Personas Juridicas)</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                        <div class="form-group">
                            <label for="num_documento">Número documento</label>
                            <input value="<?php echo e($cli->num_documento); ?>" type="text" name="num_documento" class="form-control"
                                   placeholder="Número de documento...">
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                        <div class="form-group">
                            <label for="telefono">Teléfono</label>
                            <input type="text" value="<?php echo e($cli->telefono); ?>" name="telefono" class="form-control" placeholder="Teléfono...">
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" name="email" value="<?php echo e($cli->email); ?>" class="form-control" placeholder="Email...">
                        </div>
                    </div>
                </div>
                <?php echo Form::close(); ?>

            </div>
            <div class="modal-footer">
                <button type="reset" class="btn btn-outline pull-left  btn-xs" data-dismiss="modal"><i
                            class="fa fa-window-close"></i> Cancelar
                </button>
                <button type="submit" form="edit-<?php echo e($cli->idpersona); ?>" class="btn btn-outline  btn-xs"><i
                            class="fa fa-save"></i> Guardar
                </button>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div><?php /**PATH C:\laragon\www\sisventanew\resources\views/ventas/cliente/modal-editar.blade.php ENDPATH**/ ?>