<div class="modal modal-info" aria-hidden="true" role="dialog" tabindex="-1" id="modal_fecha">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden='true'>x</span>
                </button>
                <h4 class="modal-title"><i class="fa fa-calculator"></i> Ganancia por mes de arqueo</h4>
            </div>
            <div class="modal-body" style="overflow-y: auto;background-color: #ffffff !important; color: black !important;">
                <div class="table-responsive">
                    <table class="table table-striped table-bordered table-condensed table-hover">
                        <thead>
                            <th>Mes/Año</th>
                            <th>Pago en Efectivo</th>
                            <th>Pago en Debito</th>
                            <th>Pago en Credito</th>
                           
                            <th>Ganancia</th>
                        </thead>
                        <?php $__currentLoopData = $resultado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tbody>
                            <tr>
                                <td><?php echo e($res->month); ?>/<?php echo e($res->year); ?></td>
                                <td>$ <?php echo e($res->efectivo); ?></td>
                                <td>$ <?php echo e($res->debito); ?></td>
                                <td>$ <?php echo e($res->credito); ?></td>
                               
                                <td>$ <?php echo e(($res->efectivo)+($res->debito)+($res->credito)); ?></td>
                            </tr>
                            </tbody>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
            <div class="modal-footer">
                <a class="btn btn-outline  btn-xs" href="<?php echo e(route('pdf.arqueo')); ?>" ><i class="fa fa-print"></i> Descargar PDF</a>
                <button type="button" class="btn btn-outline pull-left  btn-xs" data-dismiss="modal"><i class="fa fa-window-close"></i> Cerrar</button>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\laragon\www\sisventaobran\resources\views/arqueo/feche-modal.blade.php ENDPATH**/ ?>