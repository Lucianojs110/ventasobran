<?php

namespace SisVentaNew\Observers;

class FireSyncObserver
{
    //
}
